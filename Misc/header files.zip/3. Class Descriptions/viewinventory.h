/*---------- Class Description -----------
This class extends the transaction class, and is specifically a 
transaction to view the inventory of the store.
*/

class ViewInventory : Transaction {


public:

    //perform the transaction
	bool doTransaction();
};

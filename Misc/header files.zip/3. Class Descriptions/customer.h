/*---------- Class Description -----------
This class represents a customer of the store. 
Each customer has two pieces of information.
The object contains two fields. One is "customerID" which represents
the customers ID number. The other is "name" which represnts the name 
of the customer. The Store class has a BST which contains Customer objects.
The BST reads the data4customers.txt file, extracts information about each
customer and creates an Customer object for each customer. 
*/ 
class Customer {

private:
	int customerID;
	string name;

public:

    // returns the customerID - used to find a customer in the hash table
	int getCustomerID();

    // passes in a parameter and sets the customerID field according to the
    // value of the parameter
	void setCustomerID(int customerID);

    // returns the name of the customer
	string getName();

    // sets the name of the customer according to the value of the parameter.
	void setName(string name);
	
};

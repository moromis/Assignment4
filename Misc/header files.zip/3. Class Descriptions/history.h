/*---------- Class Description -----------
This class extends the transaction class, and is specifically a 
transaction to display the history of transactions of the store.
*/

class History : Transaction {


public:

    //perform the transaction
	bool doTransaction();
};

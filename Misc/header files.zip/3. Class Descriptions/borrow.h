/*---------- Class Description -----------
This class extends the transaction class, and is specifically a transaction to
borrow a movie from the store.
*/

class Borrow : Transaction {


public:

    //perform the transaction
	bool doTransaction();
};

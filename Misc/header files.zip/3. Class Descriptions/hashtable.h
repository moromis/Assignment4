/*---------- Class Description -----------
This class represents a hash table of the customers that the store has on
record. The hashtable is implemented using an array of linked lists -- i.e.
an open hashtable.
*/

class HashTable {

private:
    
    //array to hold the linked lists which we hash customers into
	Customer* array;
	
	//length of the array
	int length;

public:

    //retrieves a customer from the table
	Customer* retrieveCustomer(int year);

private:

    //hashes a customer based on their ID
	int hash(int customerID);
};
